# Publishing new version

- Update version in `package.json`
- `git tag vx.x.x`
- `git push --tags`
- `node publish.js` (publishes packages to npm)
